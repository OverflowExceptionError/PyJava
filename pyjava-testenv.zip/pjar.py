import shutil,sys
from zipfile import ZipFile
def make():
    try:
        shutil.make_archive(sys.argv[2], 'zip', sys.argv[1])
        name = sys.argv[2]
    except:
        try:
            shutil.make_archive(sys.argv[1], 'zip', sys.argv[1])
            name = sys.argv[1]
        except:
            shutil.make_archive('default','zip','default')
            name = 'default'
    a = open('libs/' + name + '.pjar','wb')
    b = open(name + '.zip','rb')
    a.write(b.read())
    b.close()
    a.close()
def read(file):
    with ZipFile(file, 'r') as zip_ref:
        zip_ref.extractall("applet")
if __name__ == '__main__':
    make()