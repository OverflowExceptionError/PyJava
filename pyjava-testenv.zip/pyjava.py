try:
    import pjar
except:
    print('PyJava configuration error!')
    print('Missing executable library \'pjar\' (pjar.py)')
    exit()
import sys,shutil
try:
    pjar.read('libs/components.pjar')
except IOError:
    print('PyJava configuration error!')
    print('Missing library com.dava.components (libs/components)')
    exit()
if sys.argv[1] != 'none':
    for e in sys.argv[1].split(';'):
        try:
            pjar.read(e + '.pjar')
        except IOError:
            print('PyJava configuration error!')
            print('Missing library com.dava.external_library (' + e + ')')
            exit()
from importlib import import_module
args = sys.argv[3].split(";")
MainClass = import_module('applet.' + sys.argv[2])
if args[0] != 'debug':
    try:
        MainClass.EntryPoint(args)
    except:
        print('Oops! A PyJava applet error has occured and PyJava had to stop!')
        exit()
else:
    try:
        MainClass.EntryPoint(args)
    except:
        print('Oops! A PyJava applet error has occured and PyJava had to stop!')
        print('To show the error, we will cause another error!')
        raise Exception()
try:
    shutil.rmtree('applet')
except OSError as e:
    print ("Error: %s - %s." % (e.filename, e.strerror))