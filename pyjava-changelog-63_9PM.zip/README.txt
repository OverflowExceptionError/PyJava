PyJava
A attem- I give up.
Required files:
pyjava.py
pjar.py
importer.py
libs/components.pjar